# RG-6 RECONCILIATION MATRIX V0.3 (updated per AUTHOR DECISION, evidence-supported closures)

| Item | Status | Evidence |
|---|---|---|
| M36 | **CLOSED** (author) | TX-N2a, rows_rg5r.py, V1.4 (EIT_V277_AUTHOR_DECISION_EVIDENCE_CLOSURES_V0.1) |
| M55 | **CLOSED** (author) | TX-N2b, rows_rg5r.py, V1.4 (same) |
| M61 | **CLOSED** (author) | TX-N1, rows_rg5r.py, V1.4 (same) |
| M43 | **CLOSED WITH LIMITATION** (author) | TX-M43 V0.2, rg6/tx_m43/tx_m43.py; private-class limitation preserved (same) |
| N-8(b) | **LOCALLY EVIDENCE-SATISFIED** (author) — NOT GH Actions evidence | 82/82 OK, RC10 local (same) |
| N-8(a)/(d)/(e) | OPEN — DEFINED in RC10 workflow; awaiting real GitHub Actions execution | RC10 verify.yml; RC10_CI_LOCAL_EVIDENCE |
| N-1, N-3, N-4, N-5, N-6, N-7 | OPEN — accepted residual limitations | V0.6.0_DRAFT_V0.4 §13 |
| B4-0 | OPEN — awaits the author's written interpretation | RG6_AUTHOR_DECISION_INPUT_V0.3 §4 |
| §7 kill-tests / audit mutants (M1,M6,M10,M12,M13,M15,M16) | OPEN — separate track | KNOWN_LIMITATIONS |
| RG-6, Phase 1, Gate-4, Freeze, GitHub, Zenodo | OPEN — not closed by this decision | (author decision, REMAIN OPEN list) |
